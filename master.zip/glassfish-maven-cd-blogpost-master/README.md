glassfish-maven-cd-blogpost
===========================

Repository for my blog post, 'Building a Deployment Pipeline Using Git, Maven, Jenkins, JUnit, and GlassFish'

Build an automated deployment pipeline for your Java EE applications, using leading open-source technologies, including Git, Maven, Jenkins, JUnit, and GlassFish.
